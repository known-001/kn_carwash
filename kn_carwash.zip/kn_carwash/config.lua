Config = {}

Config.DrawDistance = 8

Config.Price = 800

Config.Blip = {
    Sprite  = 100,
    Display = 4,
    Scale   = 1.2,
    Colour  = 0
}

Config.Carwashes = {
    -- to add a new location just copy the template and add the coords
    --[[{
        spawn = vector3(20.27, -1391.78, 28.4),
    }]]
    {
        spawn = vector3(20.27, -1391.78, 28.4),
    }
}